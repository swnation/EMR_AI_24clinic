import json
from typing import List, Dict

with open("rules/rules.json", encoding="utf-8") as f:
    RULES = json.load(f)["rules"]

# 호흡기 상병 코드 목록
RESP_CODES = {"j00","j040","j060","j0180","j0390","j209","j189","j303","j22","j111"}
MUSCULO_CODES = {"m545","m542","m79","m791","m792"}

# 진해거담제 분류
ANTITUSSIVE_ADULT = {"co","cosy","drop","erdo","ac"}
ANTITUSSIVE_PED = {"dropsy","umk","ac2"}

# IM 주사제 코드 (비급여-b 코드 존재하는 것들)
IM_CODES = {"tra","d","bus","tr","mac","pheni","dexa","genta","linco","ambi","epi"}


def run_check(dx: List[str], orders: List[str], symptoms: str, patient_type: str) -> List[Dict]:
    dx_set = {c.lower().strip() for c in dx}
    order_set = {c.lower().strip() for c in orders}
    results = []

    # ① loxo + 호흡기 상병 → 근골격계 상병 없음
    if "loxo" in order_set:
        has_resp = bool(dx_set & RESP_CODES)
        has_musculo = bool(dx_set & MUSCULO_CODES)
        if has_resp and not has_musculo:
            results.append({
                "level": "err",
                "message": "loxo + 호흡기 상병만 있음 → 삭감 대상",
                "sub": "m545(아래허리통증) 등 근골격계 상병 추가 필요",
                "source": "인수인계_2026년3월.docx"
            })

    # ② cipro 방광염 1차 → n12-3 필요
    if "cipro" in order_set and "n300" in dx_set:
        if not ({"n12-3","n12-2"} & dx_set):
            results.append({
                "level": "err",
                "message": "cipro 방광염 1차 처방 시 n12-3 신우신염 NOS 상병 추가 필요",
                "sub": "방광염 n300 단독으로 cipro 1차 처방은 보험 문제",
                "source": "급성 방광염 acute cystitis.md"
            })

    # ③ levofloxacin 고용량
    if any(c in order_set for c in ["levo500","크라비트500"]):
        results.append({
            "level": "err",
            "message": "levofloxacin 500~750mg QD → 삭감 대상",
            "sub": "250mg QD x10d 사용",
            "source": "신우신염 APN acute pyelonephritis.md"
        })

    # ④ 신우신염 + 디클로페낙 → 기타근통 코드
    if "d" in order_set and ({"n12-3","n12-2"} & dx_set):
        results.append({
            "level": "warn",
            "message": "신우신염 + 디클로페낙: 자동입력 기타근통 코드 삭제 필요",
            "sub": "연결코드 m79108 기타근통 삭제",
            "source": "신우신염 APN acute pyelonephritis.md"
        })

    # ⑤ 모누롤산
    if any(c in order_set for c in ["mono","fosfomycin","모누롤산"]):
        results.append({
            "level": "warn",
            "message": "모누롤산: 반드시 1,1,1로 처방",
            "sub": "딱 한 번 복용. 단순 UTI 아닌 경우 금기",
            "source": "급성 방광염 acute cystitis.md"
        })

    # ⑥ 소아 quinolone
    if patient_type == "소아" and ({"cipro","levo","levo250","levo500"} & order_set):
        results.append({
            "level": "err",
            "message": "소아 quinolone(cipro/levofloxacin) 금기",
            "sub": "1차: augsy 또는 cefasy",
            "source": "소아 UTI.md"
        })

    # ⑦ 진해거담제 성인 2종 초과
    if patient_type == "성인":
        used_antitussive = order_set & ANTITUSSIVE_ADULT
        if len(used_antitussive) > 2:
            results.append({
                "level": "err",
                "message": f"진해거담제 {len(used_antitussive)}종 → 성인은 2종까지만 보험",
                "sub": f"사용 중: {', '.join(used_antitussive)}",
                "source": "성인 URI.md"
            })

    # ⑧ umk 소아 용량 경고
    if patient_type == "소아" and "umk" in order_set:
        results.append({
            "level": "warn",
            "message": "umk(움카민) 소아 용량 고정 — 벗어나면 삭감",
            "sub": "1~6세미만: 9mL TID / 6~12세미만: 18mL TID",
            "source": "소아 URI(만12세 미만).md"
        })

    # ⑨ 글리아티린 60세 미만 경고
    if "glia8" in order_set:
        results.append({
            "level": "warn",
            "message": "글리아티린(glia8): 60세 미만 금기 — 나이 확인 필수",
            "sub": "반드시 전화로 확인 후 처방",
            "source": "인수인계_2026년3월.docx"
        })

    # ⑩ 주사 2종 이상
    used_im = order_set & IM_CODES
    if len(used_im) >= 2:
        results.append({
            "level": "warn",
            "message": f"주사제 {len(used_im)}종 → 추가분은 비급여(-b) 코드 사용",
            "sub": f"사용 중: {', '.join(used_im)} | ex) genta→gentab",
            "source": "인수인계_2026년3월.docx"
        })

    if not results:
        results.append({
            "level": "ok",
            "message": "체크 항목 이상 없음",
            "sub": "",
            "source": ""
        })

    return results
