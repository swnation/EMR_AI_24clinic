# 구내염 stomatitis

상병: k121-1 구내염 NOS
거의 대부분 아프타성 구내염(aphthous stomatitis)
처방 기본: po


가글


기타 외용제