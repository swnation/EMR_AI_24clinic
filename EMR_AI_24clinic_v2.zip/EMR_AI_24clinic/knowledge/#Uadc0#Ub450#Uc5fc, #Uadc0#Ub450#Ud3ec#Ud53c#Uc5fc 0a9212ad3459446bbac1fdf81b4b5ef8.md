# 귀두염, 귀두포피염

기본 차팅: 성기 끝이 붓고 아파서 오는 아이들
상병: n481 귀두포피염
n481-1 귀두염
처방 기본: anti
NSAIDs/AAP

연고 쓰려면 항생제 연고정도
박트로반, 에스로반 ……
처방 코드: 물약/가루약

cefasy/augsy
lacto2 정장제
typow/dexisy

알약
cefa/aug
bru/tykid


연고
bac (mupirocin)