# 뇌전증/Epilepsy

생성일: 2023년 2월 9일 오후 4:09
텍스트: 감기약 중 항히스타민, 콧물약 주의
1세대 보다는 2,3세대로 사용하고 단기간만!

1세대 항히스타민 포함 약들
: Diphenhydramine(슬리펠, 쿨드림, 베나드릴 ; 수면유도제로 주로 쓰임)
Dimenhydrate(=55% diphenhydramine + 45% 8-chlorotheophylline ; 보나링)
Doxylamine(자미슬정/아론정 ; 수면유도제, 디클렉틴;입덧조절제)
Clemastine(마스질)
Mequitazine(프리마란,코메키나)
Triprolidine(액티피드, 화이투벤)
Chlorpheniramine(페니라민, 코푸, 코데날, 콘택골드)

Pseudoephedrine
Phenylephrine
웬만한 성인/소아 콧물약에 포함되어 있으니 꼭 필요하면 항히스타민 단일제제 고려