# 항히스타민제 정리

IM: 3세대
IV: 세대 별 비교






졸음 부작용
ceti > bepo > fexofenadine > loratadine

효과
ceti > fexofenadine > bepo

지속 시간
검사: s/e, CIx



기계 조작, 운전 등 영향 줄 수 있음을 warning

뇌전증 환자는 1세대는 금기, 꼭 필요시에는 2~3세대(가급적 사용 권장 안함)
기본 차팅: 본원에서 사용하는 항히스타민제제

ceti/cetisy
bepo
olo
keto/keto2
phen
fexo
상병: 주로 쓰는 상병 중 항히스타민제 보험 사용 가능한 상병들

- l309 상세불명 피부염
- l500 알레르기 피부염
- j303 비염
- b009-1 단순포진
- b029 대상포진
처방 기본: 1세대
처방 코드: 2세대




타원에서 많이 사용하는 항히스타민

bepotastine : BID, 타리온, 투리온, 간대사 없어서 상대적으로 안전. 작용 빠르나 반감기도 짧음
olopatadine
cetirizine : 지르텍
levocetirizine : QD, 씨잘
fexofenadine : QD, 알레그라, 간대사 없어서 상대적으로 안전
ketotifen
loratadine
epinastine
ebastine
loratadine : 클라리틴, 작용 느리고 오래감, 효과 적으나 졸음 부작용 제일 적은 편